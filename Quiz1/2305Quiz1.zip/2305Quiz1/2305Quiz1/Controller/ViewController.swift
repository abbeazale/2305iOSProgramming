//
//  ViewController.swift
//  2305Quiz1
//
//  Created by Abbe Azale on 2022-02-02.
//

import UIKit

class ViewController: UIViewController {
    
    private let govForm = UILabel()
    private let name = UILabel()
    private let userName = UITextField()
    private let nationality = UILabel()
    private let userNationality = UITextField()
    private let nameResults = UILabel()
    private let nationalityResults = UILabel()
    private let submitButton = UIButton()
    private let plusButton = UIButton()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        didLoadSetup()
    }

}

extension ViewController {
    @objc func handleSubmitDidTouchUpInside(){
        nameResults.text = userName.text
        nationalityResults.text = userNationality.text
    }
}
private extension ViewController{
    
    func didLoadSetup(){
        view.addSubviews(views: govForm, name, userName, nationality, userNationality, nameResults, nationalityResults, submitButton, plusButton)
        setupGovForm()
        setupName()
        setupUserName()
        setupNationality()
        setupUserNationality()
        setupResults()
        setupNatResults()
        setupSubmitButton()
        setupPlusButton()
    }
    
    func setupGovForm(){
        govForm.translatesAutoresizingMaskIntoConstraints = false
        govForm.text = "Every Government Form Ever"
        govForm.font = UIFont.systemFont(ofSize: 25)
        govForm.textAlignment = .center
        govForm.numberOfLines = 0
        govForm.lineBreakMode = .byWordWrapping
       
        
        NSLayoutConstraint.activate([
            govForm.safeAreaLayoutGuide.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            govForm.safeAreaLayoutGuide.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            govForm.safeAreaLayoutGuide.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 40)
        
        ])
    }
    
    func setupName(){
        name.translatesAutoresizingMaskIntoConstraints = false
        name.text = "Name: "
        
        
        NSLayoutConstraint.activate([
            name.safeAreaLayoutGuide.topAnchor.constraint(equalTo: govForm.bottomAnchor, constant: 40),
            name.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 15)
            
        ])
    }
    
    
    func setupUserName(){
        userName.translatesAutoresizingMaskIntoConstraints = false
        userName.placeholder = "enter your name"
        
        NSLayoutConstraint.activate([
            userName.safeAreaLayoutGuide.topAnchor.constraint(equalTo: govForm.bottomAnchor, constant: 40),
            userName.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: name.rightAnchor, constant: 20)
        ])
    }
    
    func setupNationality(){
        nationality.translatesAutoresizingMaskIntoConstraints = false
        nationality.text = "Nationality: "
        
        NSLayoutConstraint.activate([
            nationality.safeAreaLayoutGuide.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 40),
            nationality.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 15)
            
        ])
        
    }
    
    func setupUserNationality(){
        userNationality.translatesAutoresizingMaskIntoConstraints = false
        userNationality.placeholder = "enter your nationality"
        
        NSLayoutConstraint.activate([
            userNationality.safeAreaLayoutGuide.topAnchor.constraint(equalTo: name.bottomAnchor, constant: 40),
            userNationality.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: nationality.rightAnchor, constant: 20)
        ])
    }
    
    func setupResults(){
        nameResults.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            nameResults.safeAreaLayoutGuide.topAnchor.constraint(equalTo: userNationality.bottomAnchor, constant: 50),
            nameResults.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 15)
            
        ])
    }
    
    func setupNatResults(){
        nationalityResults.translatesAutoresizingMaskIntoConstraints = false
        
        
        NSLayoutConstraint.activate([
            nationalityResults.safeAreaLayoutGuide.topAnchor.constraint(equalTo: nameResults.bottomAnchor, constant: 10),
            nationalityResults.safeAreaLayoutGuide.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 15)
        
        ])
    }
    
    func setupSubmitButton(){
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        
        submitButton.setTitle("Submit", for: .normal)
        submitButton.addTarget(self, action: #selector(handleSubmitDidTouchUpInside), for: .touchUpInside)
        submitButton.backgroundColor = .systemGray6
        submitButton.setTitleColor(.black, for: .normal)
        submitButton.layer.cornerRadius = 20
        submitButton.layer.masksToBounds = false
        
        NSLayoutConstraint.activate([
            submitButton.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor,constant: -10),
            submitButton.safeAreaLayoutGuide.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            submitButton.safeAreaLayoutGuide.widthAnchor.constraint(equalTo: submitButton.safeAreaLayoutGuide.heightAnchor, multiplier: 3),
            submitButton.safeAreaLayoutGuide.heightAnchor.constraint(equalToConstant: 40)
        ])
    }
    
    func setupPlusButton(){
        plusButton.translatesAutoresizingMaskIntoConstraints = false
        plusButton.setTitle("+", for: .normal)
        plusButton.backgroundColor = .systemGray6
        plusButton.setTitleColor(.black, for: .normal)
        plusButton.layer.cornerRadius = 15
        plusButton.layer.masksToBounds = false
        
        NSLayoutConstraint.activate([
            plusButton.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            plusButton.safeAreaLayoutGuide.rightAnchor.constraint(equalTo: submitButton.safeAreaLayoutGuide.rightAnchor, constant: 90)
            
        ])
        
    }
}


extension UIView{
    //variadic perameter
    func addSubviews(views: UIView...){
        for view in views {
            self.addSubview(view)
        }
    }
}


